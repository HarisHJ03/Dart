
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'Example' 
 * Target:  'MCBSTM32F400' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H

#define RTE_DEVICE_STARTUP_STM32F4xx    /* Device Startup for STM32F4 */
#define RTE_Graphics_Core               /* Graphics Core */
#define RTE_Graphics_LCD_MCBQVGA_LG_16  /* Graphics LCD MCBQVGA_LG 16-bit IF */

#endif /* RTE_COMPONENTS_H */
