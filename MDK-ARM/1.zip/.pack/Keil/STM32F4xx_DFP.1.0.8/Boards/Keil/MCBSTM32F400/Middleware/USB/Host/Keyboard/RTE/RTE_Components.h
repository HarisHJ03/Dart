
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'Keyboard' 
 * Target:  'STM32F407 Flash' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H

#define RTE_DEVICE_STARTUP_STM32F4xx    /* Device Startup for STM32F4 */
#define RTE_Drivers_USBH0               /* Driver USBH0 */
#define RTE_Drivers_USBH1               /* Driver USBH1 */
#define RTE_USB_Core                    /* USB Core */
#define RTE_USB_Host_0                  /* USB Host 0 */
#define RTE_USB_Host_1                  /* USB Host 1 */
#define RTE_USB_Host_HID                /* USB Host HID */

#endif /* RTE_COMPONENTS_H */
